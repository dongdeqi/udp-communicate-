# UDPCommunication
 一个使用udp协议的即时沟通小软件

 ### 登录界面
 ![avatar](https://github.com/ilvli/UDPCommunication/blob/master/Screenshot/login.JPG)

### 主界面

![avatar](https://github.com/ilvli/UDPCommunication/blob/master/Screenshot/main.JPG)

